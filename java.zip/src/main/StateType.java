package main;

public enum StateType {
    Moved,
    WrongMove,
    Blackwon,
    Whitewon,
    Tie;

}
