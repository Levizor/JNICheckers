package main;

public enum CheckerType {
    Blank,
    Blackman,
    Whiteman,
    Blackking,
    Whiteking;
}
